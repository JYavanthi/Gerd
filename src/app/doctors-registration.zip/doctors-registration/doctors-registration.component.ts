import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute,  } from '@angular/router';
import { FormvalidationService } from '../formvalidation.service';
import { HttpserviceService } from '../httpservice.service';
import { API_URLS } from '../shared/API-URLs';
import { Router } from '@angular/router';



@Component({
  selector: 'app-doctors-registration',
  templateUrl: './doctors-registration.component.html',
  styleUrl: './doctors-registration.component.css'
})
export class DoctorsRegistrationComponent {
  doctorForm: FormGroup;
  showCodeMessage = false;
  states: Array<{ id: number; name: string }> = [];
  cities: any;
  

  constructor(
    private fb: FormBuilder,
    private formValidation: FormvalidationService,
    private http: HttpserviceService,
    private router: Router,
    public route: ActivatedRoute)
     {
    this.doctorForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      email: ['', [Validators.required, Validators.email]],
      mciCode: ['', Validators.required],
      practicePlace: ['', Validators.required],
      hospitalName: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      codeNumber: [''],
      password: ['', Validators.required],
      reenterPassword: [''],
      status: ['', Validators.required]
    });
  }


   ngOnInit(): void {
     this.loadStates();

   }
  onCodeFocus(): void {
    this.showCodeMessage = true;
  }

  onSubmit(): void {
    if (this.doctorForm.valid) {
      console.log(this.doctorForm.value);
      alert('Form submitted successfully!');
    } else {
      alert('Please fill all required fields.');
    }
  }


  Submit() {
    if (!this.formValidation.validateForm(this.doctorForm)) {
      this.doctorForm.markAllAsTouched();
      return;
    }

    const agentId = this.route.snapshot.paramMap.get('id');
    const param = {
      "flag": "I",
      "doctorID": 0,
      "name": this.doctorForm.controls ['firstName'].value,
      "email": this.doctorForm.controls['email'].value,
      "phoneNO": this.doctorForm.controls ['phone'].value,
      "mciCode": this.doctorForm.controls ['mciCode'].value,
      "placeOfPractice": this.doctorForm.controls ['practicePlace'].value,
      "hospitalName": this.doctorForm.controls ['hospitalName'].value,
      "password": this.doctorForm.controls ['password'].value,
      "state": Number(this.doctorForm.controls['state'].value),
      "city": Number(this.doctorForm.controls['city'].value),
      "enterCodeNO": this.doctorForm.controls ['codeNumber'].value,
      "status": this.doctorForm.controls ['status'].value,
      "createdBy": 0
    }
    this.http.httpPost(API_URLS.DOCTOR_REG_SAVE, param).subscribe((res: any) => {
      debugger 
     if (res.type === 'S') {
      this.formValidation.showAlert('Doctor registered successfully!', 'success');
      this.doctorForm.reset();
    } else {
      this.formValidation.showAlert('Error!!', 'danger');
    }
    });
  }
  getCities(event: any) {
  this.http.httpGet(API_URLS.CITY_GET, { stateId: event.target.value }).subscribe({
    next: (res: any) => {
      // Sort cities alphabetically by name
      this.cities = res.sort((a: any, b: any) => {
        const nameA = a.name.toLowerCase();
        const nameB = b.name.toLowerCase();
        return nameA.localeCompare(nameB);
      });
    },
    error: (err) => {
      this.formValidation.showAlert('Error loading cities', 'danger');
      console.error(err);
    }
  });
}

 loadStates() {
  if (this.states.length === 0) {
    this.http.httpGet(API_URLS.STATE_GET).subscribe({
      next: (res: any) => {
        // Sort states alphabetically by name
        this.states = res.sort((a: any, b: any) => {
          const nameA = a.name.toLowerCase();
          const nameB = b.name.toLowerCase();
          return nameA.localeCompare(nameB);
        });
      },
      error: (err) => {
        this.formValidation.showAlert('Error loading states', 'danger');
        console.error(err);
      }
    });
  }
}

  login() {
    this.router.navigate(['/login']);
  }
}
